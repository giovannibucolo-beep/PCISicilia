/* ============================================================
   PCI Sicilia — script
   ============================================================ */

/* --- Configurazione ---------------------------------------
   URL "pulito" della pagina Facebook ufficiale.
   Aggiornare anche il data-href del blocco .fb-page in index.html
----------------------------------------------------------- */
window.FB_PAGE_URL = "https://www.facebook.com/PCISicilia";

document.addEventListener("DOMContentLoaded", function () {

  /* Anno corrente nel footer */
  var y = document.getElementById("year");
  if (y) y.textContent = new Date().getFullYear();

  /* Menu mobile */
  var toggle = document.getElementById("navToggle");
  var nav = document.getElementById("mainNav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    nav.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* Reveal on scroll */
  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && reveals.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("in"); });
  }

  /* Tab eventi (prossimi / passati) */
  var tabBtns = document.querySelectorAll(".tab-btn");
  tabBtns.forEach(function (btn) {
    btn.addEventListener("click", function () {
      var target = btn.getAttribute("data-tab");
      tabBtns.forEach(function (b) { b.classList.toggle("active", b === btn); });
      document.querySelectorAll("[data-panel]").forEach(function (p) {
        p.hidden = (p.getAttribute("data-panel") !== target);
      });
    });
  });

  /* Form iscrizione (demo lato client) */
  var form = document.getElementById("joinForm");
  var msg = document.getElementById("formMsg");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var nome = form.nome.value.trim();
      var email = form.email.value.trim();
      var privacy = form.privacy.checked;
      var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      if (!nome || !emailOk || !privacy) {
        msg.textContent = "Compila nome, email valida e accetta il consenso.";
        msg.className = "form-msg err";
        return;
      }
      /* NOTA: per ricevere davvero le richieste, collega il form a un
         servizio email (es. Formspree): imposta form action/method o
         una fetch() verso l'endpoint. Per ora mostra conferma a schermo. */
      msg.textContent = "Grazie " + nome + "! La tua richiesta è stata registrata: ti ricontatteremo presto.";
      msg.className = "form-msg ok";
      form.reset();
    });
  }

  loadFacebookSDK();
});

function loadFacebookSDK() {
  if (!document.querySelector(".fb-page")) return;
  if (document.getElementById("facebook-jssdk")) return;
  var js = document.createElement("script");
  js.id = "facebook-jssdk";
  js.async = true; js.defer = true; js.crossOrigin = "anonymous";
  js.src = "https://connect.facebook.net/it_IT/sdk.js#xfbml=1&version=v19.0";
  js.onerror = showFbFallback;
  document.body.appendChild(js);
  setTimeout(function () {
    var wrap = document.querySelector(".fb-embed-wrap");
    if (wrap && !wrap.querySelector("iframe")) showFbFallback();
  }, 4500);
}

function showFbFallback() {
  var wrap = document.querySelector(".fb-embed-wrap");
  if (!wrap || wrap.dataset.fallback === "1") return;
  wrap.dataset.fallback = "1";
  var url = window.FB_PAGE_URL || "https://www.facebook.com";
  wrap.innerHTML =
    '<p class="fb-fallback">Gli ultimi post non si caricano qui (controlla l\'URL della pagina o le impostazioni del browser). ' +
    '<a href="' + url + '" target="_blank" rel="noopener">Apri la pagina Facebook →</a></p>';
}
